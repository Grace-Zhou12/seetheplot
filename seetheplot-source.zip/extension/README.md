# SEETHEPLOT VS Code extension

SEETHEPLOT displays the generated Matplotlib image inside VS Code. Titles,
axis labels, text, annotations, and legends with a reliable source location
are outlined on top of the image. Drag an outline or edit its properties, then
click **Confirm & update Python**. The extension writes a format-preserving
source edit through LibCST and regenerates the image.

The VSIX bundles the Python core source. The selected Python interpreter still
needs the runtime dependencies:

```bash
python -m pip install matplotlib numpy libcst
```

If you are using the SEETHEPLOT development workspace, the repository already
contains a working environment at `../core/.venv`. Set
`seetheplot.pythonPath` to that interpreter instead of installing packages
again when PyPI is unavailable:

```text
/Users/xinyuan/Desktop/自学ing/vbcoding/02 seetheplot/core/.venv/bin/python3
```

To build a publishable VSIX:

```bash
npm install
npm run package
```

To start the interactive preview during development, open this `extension`
folder in VS Code and press `F5`. A new Extension Development Host window will
open. In that window open a Python file and run `SEETHEPLOT: Open Preview`.
