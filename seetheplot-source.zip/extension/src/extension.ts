import * as fs from "node:fs";
import * as path from "node:path";
import { ChildProcessWithoutNullStreams, spawn } from "node:child_process";
import * as vscode from "vscode";

type Request = Record<string, unknown>;
type Response = { ok: boolean; result?: any; error?: string; traceback?: string };

class CoreClient {
  private process?: ChildProcessWithoutNullStreams;
  private buffer = "";
  private pending: Array<(response: Response) => void> = [];

  constructor(private readonly python: string, private readonly cwd: string, private readonly bundledCore: string) {}

  private ensureProcess() {
    if (this.process && !this.process.killed) return;
    const pythonPath = [this.bundledCore, process.env.PYTHONPATH].filter(Boolean).join(path.delimiter);
    this.process = spawn(this.python, ["-m", "seetheplot.cli", "serve"], {
      cwd: this.cwd,
      env: { ...process.env, PYTHONPATH: pythonPath },
    });
    this.process.stdout.setEncoding("utf8");
    this.process.stdout.on("data", (chunk: string) => {
      this.buffer += chunk;
      const lines = this.buffer.split("\n");
      this.buffer = lines.pop() ?? "";
      for (const line of lines) {
        if (!line.trim()) continue;
        const callback = this.pending.shift();
        if (callback) callback(JSON.parse(line) as Response);
      }
    });
    this.process.stderr.on("data", (chunk: Buffer) => console.error(`[seetheplot] ${chunk.toString()}`));
    this.process.on("error", (error) => {
      const callbacks = this.pending.splice(0);
      for (const callback of callbacks) callback({ ok: false, error: error.message });
    });
    this.process.on("close", (code) => {
      if (code === 0) return;
      const callbacks = this.pending.splice(0);
      for (const callback of callbacks) callback({ ok: false, error: `SEETHEPLOT core exited with code ${code ?? "unknown"}` });
    });
  }

  request(request: Request): Promise<Response> {
    this.ensureProcess();
    return new Promise((resolve, reject) => {
      if (!this.process) return reject(new Error("SEETHEPLOT core process unavailable"));
      this.pending.push(resolve);
      this.process.stdin.write(`${JSON.stringify(request)}\n`);
    });
  }

  dispose() {
    this.process?.kill();
  }
}

function pythonPath(extensionPath?: string, resource?: vscode.Uri): string {
  const configured = vscode.workspace.getConfiguration("seetheplot").get<string>("pythonPath");
  if (configured) return configured;
  try {
    const pythonExtension = vscode.extensions.getExtension("ms-python.python");
    const details = pythonExtension?.exports?.settings?.getExecutionDetails?.(resource);
    const command = Array.isArray(details?.execCommand) ? details.execCommand[0] : undefined;
    if (command) return command;
  } catch {
    // The Python extension is optional; fall back to the bundled/dev defaults.
  }
  if (extensionPath) {
    const bundled = path.resolve(extensionPath, "..", "core", ".venv", "bin", "python3");
    if (fs.existsSync(bundled)) return bundled;
  }
  return "python3";
}

function bundledCorePath(extensionPath: string): string {
  const packaged = path.join(extensionPath, "core_src");
  if (fs.existsSync(path.join(packaged, "seetheplot", "cli.py"))) return packaged;
  return path.resolve(extensionPath, "..", "core", "src");
}

function dataUri(filePath: string): string {
  const content = fs.readFileSync(filePath, "utf8");
  return `data:image/svg+xml;base64,${Buffer.from(content, "utf8").toString("base64")}`;
}

function cachedManifest(sourcePath: string): any | undefined {
  const root = path.dirname(sourcePath);
  const cacheRoot = path.join(root, ".seetheplot", "cache");
  if (!fs.existsSync(cacheRoot)) return undefined;
  const candidates = fs.readdirSync(cacheRoot)
    .map((name) => path.join(cacheRoot, name, "manifest.json"))
    .filter((file) => fs.existsSync(file))
    .map((file) => ({ file, mtime: fs.statSync(file).mtimeMs }))
    .sort((a, b) => b.mtime - a.mtime);
  for (const candidate of candidates) {
    try {
      const manifest = JSON.parse(fs.readFileSync(candidate.file, "utf8"));
      if (manifest.source?.path === sourcePath) return manifest;
    } catch {
      // Ignore incomplete cache entries and continue with the next one.
    }
  }
  return undefined;
}

function panelHtml(extensionPath: string, webview: vscode.Webview): string {
  const script = webview.asWebviewUri(vscode.Uri.file(path.join(extensionPath, "dist", "webview.js")));
  return `<!doctype html><html><head><meta charset="UTF-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src data:; script-src ${webview.cspSource}; style-src 'unsafe-inline' ${webview.cspSource};"><style>html,body,#root{height:100%;margin:0;padding:0}</style></head><body><div id="root"></div><script src="${script}"></script></body></html>`;
}

async function openPreview(context: vscode.ExtensionContext, document: vscode.TextDocument) {
  const panel = vscode.window.createWebviewPanel("seetheplot", `SEETHEPLOT: ${path.basename(document.fileName)}`, vscode.ViewColumn.Active, { enableScripts: true, retainContextWhenHidden: true });
  panel.webview.html = panelHtml(context.extensionPath, panel.webview);
  const client = new CoreClient(
    pythonPath(context.extensionPath, document.uri),
    vscode.workspace.getWorkspaceFolder(document.uri)?.uri.fsPath ?? path.dirname(document.fileName),
    bundledCorePath(context.extensionPath),
  );
  let manifest: any;
  let running = false;
  const timeoutMs = Math.max(1000, Number(vscode.workspace.getConfiguration("seetheplot").get("timeoutSeconds", 30)) * 1000);

  const run = async (mode = "full") => {
    if (running) return;
    running = true;
    panel.webview.postMessage({ type: "status", message: "Running Python preview…" });
    try {
      const response = await Promise.race<Response | undefined>([
        client.request({ command: "run", source_path: document.fileName, workspace: vscode.workspace.getWorkspaceFolder(document.uri)?.uri.fsPath ?? path.dirname(document.fileName), mode }),
        new Promise<undefined>((resolve) => setTimeout(() => resolve(undefined), timeoutMs)),
      ]);
      if (response?.ok) {
        manifest = response.result;
      } else {
        manifest = cachedManifest(document.fileName);
        if (!manifest) throw new Error(response?.error ?? "SEETHEPLOT run timed out and no cached preview was found");
        panel.webview.postMessage({ type: "status", message: "Loaded cached preview" });
      }
      const assets = manifest.assets ?? {};
      for (const key of ["full_render", "skeleton_render"]) {
        if (assets[key]) assets[key] = dataUri(assets[key]);
      }
      panel.webview.postMessage({ type: "manifest", manifest });
    } catch (error) {
      panel.webview.postMessage({ type: "error", message: String(error) });
      void vscode.window.showErrorMessage(`SEETHEPLOT: ${String(error)}`);
    } finally {
      running = false;
    }
  };

  panel.webview.onDidReceiveMessage(async (message) => {
    if (message.type === "run") await run(message.mode ?? "full");
    if (message.type === "apply") {
      if (!manifest) return;
      if (document.isDirty) {
        void vscode.window.showWarningMessage("Save the Python file and run SEETHEPLOT again before applying edits.");
        return;
      }
      const response = await client.request({ command: "patch", source_path: document.fileName, manifest, operations: message.operations ?? [] });
      if (!response.ok) {
        void vscode.window.showErrorMessage(`SEETHEPLOT: ${response.error ?? "Patch failed"}`);
        return;
      }
      const result = response.result;
      if (result.reanalyze_required) {
        void vscode.window.showWarningMessage("The Python file changed after preview; run SEETHEPLOT again before applying edits.");
        return;
      }
      if (!result.diff) {
        panel.webview.postMessage({ type: "patchResult", result });
        return;
      }
      if (result.unsupported_operations?.length) {
        void vscode.window.showWarningMessage(`SEETHEPLOT skipped ${result.unsupported_operations.length} unsupported edit(s). The source was not changed.`);
        panel.webview.postMessage({ type: "patchResult", result });
        return;
      }
      const diffDocument = await vscode.workspace.openTextDocument({ content: result.diff, language: "diff" });
      await vscode.window.showTextDocument(diffDocument, { viewColumn: vscode.ViewColumn.Beside, preview: true });
      const choice = await vscode.window.showInformationMessage("Review the diff, then apply SEETHEPLOT source changes?", "Apply", "Cancel");
      if (choice === "Apply") {
        const edit = new vscode.WorkspaceEdit();
        edit.replace(document.uri, new vscode.Range(document.positionAt(0), document.positionAt(document.getText().length)), result.changed_source);
        await vscode.workspace.applyEdit(edit);
        await document.save();
        panel.webview.postMessage({ type: "patchResult", result });
        await run("full");
      }
    }
  });
  panel.onDidDispose(() => client.dispose());
  void run("full");
}

export function activate(context: vscode.ExtensionContext) {
  const open = vscode.commands.registerCommand("seetheplot.openPreview", () => {
    const editor = vscode.window.activeTextEditor;
    if (!editor || editor.document.languageId !== "python") {
      void vscode.window.showWarningMessage("Open a Python plotting file first.");
      return;
    }
    void openPreview(context, editor.document);
  });
  const run = vscode.commands.registerCommand("seetheplot.runCurrentFile", () => {
    const editor = vscode.window.activeTextEditor;
    if (editor?.document.languageId === "python") void openPreview(context, editor.document);
  });
  context.subscriptions.push(open, run);
}

export function deactivate() {}
