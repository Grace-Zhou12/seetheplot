import React, { useEffect, useMemo, useRef, useState } from "react";
import { createRoot } from "react-dom/client";

declare function acquireVsCodeApi(): { postMessage(message: unknown): void };
const vscode = acquireVsCodeApi();

type Bounds = { x: number; y: number; width: number; height: number };
type ElementModel = {
  id: string;
  kind: string;
  bounds: Bounds;
  properties: Record<string, any>;
  editable_properties: string[];
  source_ref?: { call_name?: string; start_line?: number };
};
type FigureModel = {
  width: number;
  height: number;
  dpi: number;
  width_px?: number;
  height_px?: number;
  axes: Array<{ bounds: Bounds; elements: ElementModel[] }>;
  elements: ElementModel[];
};
type Manifest = { assets: Record<string, string>; figures: FigureModel[] };
type Operation = { element_id: string; property_path: string; value: any };
type DragSession = { element: ElementModel; startX: number; startY: number };

function allElements(manifest: Manifest | undefined): ElementModel[] {
  if (!manifest) return [];
  return manifest.figures.flatMap((figure) => [
    ...figure.elements,
    ...figure.axes.flatMap((axes) => axes.elements),
  ]);
}

function labelFor(element: ElementModel): string {
  const text = typeof element.properties.text === "string" ? element.properties.text.replace(/\s+/g, " ").trim() : "";
  return `${element.kind}${text ? ` · ${text}` : ""}`;
}

function canDrag(element: ElementModel): boolean {
  if (element.kind === "text" || element.kind === "annotation") return Boolean(element.properties.position_display && element.properties.axes_bounds);
  if (element.kind === "title" || element.kind === "axis_label") return Boolean(element.properties.position_display && element.properties.axes_bounds);
  if (element.kind === "legend") return Boolean(element.properties.bbox_to_anchor && element.properties.axes_bounds);
  return false;
}

function App() {
  const [manifest, setManifest] = useState<Manifest>();
  const [mode, setMode] = useState<"full" | "skeleton">("full");
  const [selected, setSelected] = useState<string>();
  const [operations, setOperations] = useState<Operation[]>([]);
  const [status, setStatus] = useState("Waiting for preview…");
  const [drag, setDrag] = useState<DragSession>();
  const [draftDelta, setDraftDelta] = useState<Record<string, { x: number; y: number }>>({});
  const stageRef = useRef<HTMLDivElement>(null);
  const elements = useMemo(() => allElements(manifest), [manifest]);
  const current = elements.find((element) => element.id === selected);
  const figure = manifest?.figures?.[0];
  const pixelWidth = figure?.width_px ?? ((figure?.width ?? 8) * (figure?.dpi ?? 100));
  const pixelHeight = figure?.height_px ?? ((figure?.height ?? 5) * (figure?.dpi ?? 100));
  const render = manifest?.assets?.[mode === "full" ? "full_render" : "skeleton_render"];

  useEffect(() => {
    const listener = (event: MessageEvent) => {
      const message = event.data;
      if (message.type === "manifest") {
        setManifest(message.manifest);
        setDraftDelta({});
        setStatus("Preview ready — drag an outlined element or edit it on the right");
      }
      if (message.type === "status") setStatus(message.message);
      if (message.type === "error") setStatus(message.message);
      if (message.type === "patchResult") {
        setOperations([]);
        setDraftDelta({});
        setStatus("Changes applied — regenerating the preview…");
      }
    };
    window.addEventListener("message", listener);
    return () => window.removeEventListener("message", listener);
  }, []);

  const commit = (elementId: string, propertyPath: string, value: any) => {
    setOperations((existing) => [
      ...existing.filter((item) => !(item.element_id === elementId && item.property_path === propertyPath)),
      { element_id: elementId, property_path: propertyPath, value },
    ]);
    setManifest((existing) => {
      if (!existing) return existing;
      const copy = structuredClone(existing) as Manifest;
      const element = allElements(copy).find((candidate) => candidate.id === elementId);
      if (element) element.properties[propertyPath] = value;
      return copy;
    });
  };

  const imagePoint = (event: React.PointerEvent) => {
    const stage = stageRef.current;
    if (!stage) return { x: 0, y: 0 };
    const rect = stage.getBoundingClientRect();
    return {
      x: (event.clientX - rect.left) * pixelWidth / rect.width,
      y: pixelHeight - (event.clientY - rect.top) * pixelHeight / rect.height,
    };
  };

  const updateDrag = (event: React.PointerEvent) => {
    if (!drag) return;
    const point = imagePoint(event);
    const dx = point.x - drag.startX;
    const dy = point.y - drag.startY;
    const element = drag.element;
    const props = element.properties;
    const axes = props.axes_bounds as Bounds | undefined;
    setDraftDelta((existing) => ({ ...existing, [element.id]: { x: dx, y: dy } }));
    if (!axes) return;

    if (element.kind === "text" || element.kind === "annotation") {
      const position = (props.position as number[] | undefined) ?? [0, 0];
      const limits = props.axis_limits as { x: number[]; y: number[] } | undefined;
      if (!limits) return;
      commit(element.id, "position.x", position[0] + dx * (limits.x[1] - limits.x[0]) / axes.width);
      commit(element.id, "position.y", position[1] + dy * (limits.y[1] - limits.y[0]) / axes.height);
      return;
    }

    if (element.kind === "title") {
      const position = (props.layout_position as number[] | undefined) ?? [0.5, 1];
      commit(element.id, "layout.y", position[1] + dy / axes.height);
      const relativeX = point.x - axes.x;
      const loc = relativeX < axes.width * 0.34 ? "left" : relativeX > axes.width * 0.66 ? "right" : "center";
      commit(element.id, "layout.loc", loc);
      return;
    }

    if (element.kind === "axis_label") {
      const layout = props.layout as string;
      const relative = layout === "xlabel" ? point.x - axes.x : point.y - axes.y;
      const span = layout === "xlabel" ? axes.width : axes.height;
      const loc = relative < span * 0.34 ? "left" : relative > span * 0.66 ? "right" : "center";
      commit(element.id, "layout.loc", loc);
      const basePad = Number(props.labelpad ?? 4);
      const deltaPoints = (layout === "xlabel" ? dy : dx) * 72 / Number(figure?.dpi ?? 100);
      commit(element.id, "layout.labelpad", Math.max(0, basePad - deltaPoints));
      return;
    }

    if (element.kind === "legend") {
      const anchor = (props.bbox_to_anchor as number[] | undefined) ?? [0, 0, 1, 1];
      commit(element.id, "legend.bbox_to_anchor", [
        anchor[0] + dx / axes.width,
        anchor[1] + dy / axes.height,
        anchor[2],
        anchor[3],
      ]);
    }
  };

  const endDrag = () => setDrag(undefined);

  const boundsFor = (element: ElementModel): Bounds => {
    const delta = draftDelta[element.id];
    if (!delta) return element.bounds;
    return { ...element.bounds, x: element.bounds.x + delta.x, y: element.bounds.y + delta.y };
  };

  const beginDrag = (event: React.PointerEvent, element: ElementModel) => {
    if (!canDrag(element)) return;
    event.currentTarget.setPointerCapture(event.pointerId);
    setSelected(element.id);
    const point = imagePoint(event);
    setDrag({ element, startX: point.x, startY: point.y });
  };

  const apply = () => {
    if (operations.length) vscode.postMessage({ type: "apply", operations });
  };

  const clearChanges = () => {
    if (operations.length) {
      setOperations([]);
      setDraftDelta({});
      vscode.postMessage({ type: "run", mode });
    }
  };

  const overlayElements = elements.filter((element) => element.bounds && element.kind !== "tick" && element.kind !== "canvas");

  return <div className="app">
    <header className="topbar">
      <div><strong>SEETHEPLOT</strong><span className="filename">Visual layout editor · {figure ? "Matplotlib figure" : "No figure"}</span></div>
      <div className="top-actions">
        <button onClick={() => vscode.postMessage({ type: "run", mode: "full" })}>Run Python</button>
        <button onClick={() => setMode(mode === "full" ? "skeleton" : "full")}>{mode === "full" ? "Structure mode" : "Full image"}</button>
        <button className="primary" disabled={!operations.length} onClick={apply}>Confirm &amp; update Python{operations.length ? ` (${operations.length})` : ""}</button>
        <button disabled={!operations.length} onClick={clearChanges}>Discard</button>
      </div>
    </header>
    <div className="body">
      <aside className="layers">
        <h3>Elements</h3>
        <p className="hint">Click an element, or drag its blue outline directly on the image.</p>
        {elements.map((element) => <button className={element.id === selected ? "element selected" : "element"} key={element.id} onClick={() => setSelected(element.id)}>
          <span>{labelFor(element)}</span><small>{canDrag(element) ? "drag" : "inspect"}</small>
        </button>)}
      </aside>
      <main className="preview-area">
        <div className="status"><span className={operations.length ? "dot pending" : "dot"}></span>{status}</div>
        {render ? <div ref={stageRef} className="stage" style={{ aspectRatio: `${pixelWidth} / ${pixelHeight}` }} onPointerMove={updateDrag} onPointerUp={endDrag} onPointerCancel={endDrag}>
          <img src={render} alt="Generated Matplotlib preview" draggable={false} />
          <svg className="overlay" viewBox={`0 0 ${pixelWidth} ${pixelHeight}`} preserveAspectRatio="none">
            {overlayElements.map((element) => { const b = boundsFor(element); return <rect key={element.id} className={element.id === selected ? "handle selected" : "handle"} x={b.x} y={pixelHeight - b.y - b.height} width={Math.max(b.width, 10)} height={Math.max(b.height, 10)} onPointerDown={(event) => beginDrag(event, element)} />; })}
          </svg>
        </div> : <div className="empty"><strong>Run a Python plotting file to see its generated image.</strong><span>The image and editable element map will appear here.</span></div>}
        {operations.length > 0 && <div className="pending-banner">Changes are still in the preview. Click <strong>Confirm &amp; update Python</strong> to write them to the source file.</div>}
      </main>
      <aside className="inspector">
        <h3>Inspector</h3>
        {!current && <p className="hint">Select an element to edit its text, typography, position, or layout.</p>}
        {current && <>
          <div className="selection-title"><span className="kind">{current.kind}</span><strong>{labelFor(current)}</strong></div>
          {typeof current.properties.text === "string" && <label>Text<input value={current.properties.text} onChange={(event) => commit(current.id, "text", event.target.value)} /></label>}
          {typeof current.properties["font.size"] === "number" && <label>Font size<input type="number" value={current.properties["font.size"]} onChange={(event) => commit(current.id, "font.size", Number(event.target.value))} /></label>}
          {typeof current.properties.rotation === "number" && <label>Rotation<input type="number" value={current.properties.rotation} onChange={(event) => commit(current.id, "rotation", Number(event.target.value))} /></label>}
          {typeof current.properties.color === "string" && <label>Color<input value={current.properties.color} onChange={(event) => commit(current.id, "color", event.target.value)} /></label>}
          {current.kind === "legend" && <label>Legend location<input value={current.properties.loc ?? "best"} onChange={(event) => commit(current.id, "legend.loc", event.target.value)} /></label>}
          {!canDrag(current) && <p className="readonly">This element is inspectable but not draggable in v1.</p>}
          {!current.editable_properties.length && <p className="readonly">No unique source call was found, so this element is read-only.</p>}
        </>}
      </aside>
    </div>
    <style>{`*{box-sizing:border-box}body{font-family:var(--vscode-font-family);font-size:13px;color:var(--vscode-foreground);background:var(--vscode-editor-background);overflow:hidden}.app{height:100vh;display:flex;flex-direction:column}.topbar{min-height:58px;display:flex;align-items:center;justify-content:space-between;gap:16px;padding:10px 16px;border-bottom:1px solid var(--vscode-panel-border);background:var(--vscode-sideBar-background)}.topbar strong{font-size:15px;letter-spacing:.04em}.filename{margin-left:12px;color:var(--vscode-descriptionForeground);font-size:12px}.top-actions{display:flex;gap:7px;align-items:center}.top-actions button{width:auto;margin:0;white-space:nowrap}.body{display:grid;grid-template-columns:210px minmax(300px,1fr) 240px;min-height:0;flex:1}.layers,.inspector{padding:14px;overflow:auto}.layers{border-right:1px solid var(--vscode-panel-border);background:var(--vscode-sideBar-background)}.inspector{border-left:1px solid var(--vscode-panel-border);background:var(--vscode-sideBar-background)}h3{margin:2px 0 12px;font-size:13px}.hint,.readonly{color:var(--vscode-descriptionForeground);font-size:12px;line-height:1.45}.element{display:flex;justify-content:space-between;gap:8px;width:100%;margin:5px 0;padding:8px;text-align:left;color:inherit;background:var(--vscode-button-secondaryBackground);border:1px solid var(--vscode-panel-border);border-radius:3px;cursor:pointer}.element span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.element small{color:var(--vscode-descriptionForeground);font-size:10px}.element:hover,.element.selected{background:var(--vscode-button-background);color:var(--vscode-button-foreground)}button{padding:7px 10px;color:inherit;background:var(--vscode-button-secondaryBackground);border:1px solid var(--vscode-panel-border);border-radius:3px;cursor:pointer}button:hover{background:var(--vscode-button-secondaryHoverBackground)}button:disabled{opacity:.45;cursor:default}.primary{background:var(--vscode-button-background);color:var(--vscode-button-foreground);border-color:var(--vscode-button-background)}.preview-area{position:relative;min-width:0;display:flex;align-items:center;justify-content:center;overflow:auto;padding:26px}.stage{position:relative;width:min(100%,1100px);line-height:0;box-shadow:0 4px 22px #0005;background:#fff}.stage img{display:block;width:100%;height:100%;user-select:none}.overlay{position:absolute;inset:0;width:100%;height:100%;overflow:visible}.handle{fill:transparent;stroke:transparent;stroke-width:2;vector-effect:non-scaling-stroke;pointer-events:all;cursor:grab}.handle:hover,.handle.selected{stroke:#2684ff;stroke-dasharray:6 4;fill:#2684ff18}.handle:active{cursor:grabbing}.status{position:absolute;z-index:3;top:8px;left:12px;padding:5px 8px;border-radius:4px;background:var(--vscode-editorWidget-background);color:var(--vscode-descriptionForeground);font-size:11px;box-shadow:0 1px 5px #0003}.dot{display:inline-block;width:7px;height:7px;margin-right:6px;border-radius:50%;background:#4caf50}.dot.pending{background:#f2b01e}.empty{display:flex;flex-direction:column;gap:10px;align-items:center;justify-content:center;max-width:450px;color:var(--vscode-descriptionForeground);text-align:center}.pending-banner{position:absolute;bottom:14px;left:50%;transform:translateX(-50%);padding:9px 14px;border:1px solid #2684ff99;border-radius:5px;background:var(--vscode-editorWidget-background);box-shadow:0 2px 10px #0004;font-size:12px}.selection-title{display:flex;flex-direction:column;gap:3px;padding-bottom:12px;border-bottom:1px solid var(--vscode-panel-border)}.kind{color:var(--vscode-textLink-foreground);font-size:11px;text-transform:uppercase}.selection-title strong{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}label{display:block;margin:15px 0 0;font-size:12px;color:var(--vscode-descriptionForeground)}input{display:block;width:100%;margin-top:6px;padding:7px;color:var(--vscode-input-foreground);background:var(--vscode-input-background);border:1px solid var(--vscode-input-border);border-radius:3px}`}</style>
  </div>;
}

createRoot(document.getElementById("root")!).render(<App />);
