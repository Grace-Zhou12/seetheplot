import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const extensionDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const sourceDir = path.resolve(extensionDir, "..", "core", "src");
const targetDir = path.join(extensionDir, "core_src");

if (!fs.existsSync(path.join(sourceDir, "seetheplot", "cli.py"))) {
  throw new Error(`SEETHEPLOT core source not found: ${sourceDir}`);
}
fs.rmSync(targetDir, { recursive: true, force: true });
fs.cpSync(sourceDir, targetDir, { recursive: true });
console.log(`Bundled Python core into ${targetDir}`);
