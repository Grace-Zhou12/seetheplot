# seetheplot-core

The Python engine for SEETHEPLOT. It runs a plotting script in an Agg
subprocess, emits a versioned manifest, renders full and layout-only previews,
and produces minimal LibCST source patches for supported layout operations.
