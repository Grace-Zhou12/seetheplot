from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path

import pytest

pytest.importorskip("libcst")

from seetheplot.patcher import patch_source
from seetheplot.runner import run_script


FIXTURE = Path(__file__).parent / "fixtures" / "basic_plot.py"


def test_run_creates_manifest_and_both_previews(tmp_path: Path) -> None:
    source = tmp_path / "basic_plot.py"
    shutil.copy2(FIXTURE, source)
    manifest = run_script(str(source), workspace=str(tmp_path))

    assert manifest["schema_version"] == 1
    assert manifest["figures"]
    assert manifest["figures"][0]["width_px"] > 0
    assert manifest["figures"][0]["height_px"] > 0
    assert Path(manifest["assets"]["full_render"]).exists()
    assert Path(manifest["assets"]["skeleton_render"]).exists()
    kinds = {element["kind"] for axes in manifest["figures"][0]["axes"] for element in axes["elements"]}
    assert {"title", "axis_label", "text", "annotation", "legend", "tick"} <= kinds


def test_patch_changes_literal_title_and_preserves_other_source(tmp_path: Path) -> None:
    source = tmp_path / "basic_plot.py"
    shutil.copy2(FIXTURE, source)
    manifest = run_script(str(source), workspace=str(tmp_path))
    title = next(element for element in manifest["figures"][0]["axes"][0]["elements"] if element["kind"] == "title")
    result = patch_source(str(source), manifest, [{"element_id": title["id"], "property_path": "text", "value": "Updated title"}])

    assert "Updated title" in result["changed_source"]
    assert "A demo title" not in result["changed_source"]
    assert result["diff"]
    assert not result["reanalyze_required"]


def test_patch_refuses_stale_manifest(tmp_path: Path) -> None:
    source = tmp_path / "basic_plot.py"
    shutil.copy2(FIXTURE, source)
    manifest = run_script(str(source), workspace=str(tmp_path))
    source.write_text(source.read_text() + "\n# changed externally\n", encoding="utf-8")
    title = next(element for element in manifest["figures"][0]["axes"][0]["elements"] if element["kind"] == "title")
    result = patch_source(str(source), manifest, [{"element_id": title["id"], "property_path": "text", "value": "nope"}])

    assert result["reanalyze_required"]
    assert "nope" not in result["changed_source"]


def test_patch_moves_text_annotation_and_legend(tmp_path: Path) -> None:
    source = tmp_path / "basic_plot.py"
    shutil.copy2(FIXTURE, source)
    manifest = run_script(str(source), workspace=str(tmp_path))
    elements = {
        element["kind"]: element
        for element in manifest["figures"][0]["axes"][0]["elements"]
        if element["kind"] in {"text", "annotation", "legend"}
    }
    result = patch_source(str(source), manifest, [
        {"element_id": elements["text"]["id"], "property_path": "position.x", "value": 2.5},
        {"element_id": elements["text"]["id"], "property_path": "position.y", "value": 0.7},
        {"element_id": elements["annotation"]["id"], "property_path": "position.x", "value": 1.8},
        {"element_id": elements["annotation"]["id"], "property_path": "position.y", "value": 1.2},
        {"element_id": elements["legend"]["id"], "property_path": "legend.bbox_to_anchor", "value": [0.1, 0.1, 1, 1]},
    ])

    assert not result["unsupported_operations"]
    assert "ax.text(2.5, 0.7" in result["changed_source"]
    assert "xytext=(1.8, 1.2)" in result["changed_source"]
    assert "bbox_to_anchor = [0.1, 0.1, 1, 1]" in result["changed_source"]


def test_cache_key_tracks_source_content(tmp_path: Path) -> None:
    source = tmp_path / "basic_plot.py"
    shutil.copy2(FIXTURE, source)
    first = run_script(str(source), workspace=str(tmp_path))
    source.write_text(source.read_text().replace("A demo title", "another title"), encoding="utf-8")
    second = run_script(str(source), workspace=str(tmp_path))
    assert first["cache_key"] != second["cache_key"]
