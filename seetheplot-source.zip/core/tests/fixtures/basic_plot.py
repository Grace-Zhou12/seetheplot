import matplotlib.pyplot as plt
import numpy as np

fig, ax = plt.subplots(figsize=(6, 4))
x = np.linspace(0, 2 * np.pi, 40)
ax.plot(x, np.sin(x), label="sin")
ax.set_title("A demo title", fontsize=12)
ax.set_xlabel("time")
ax.set_ylabel("value")
ax.text(1.0, 0.5, "note", fontsize=10)
ax.annotate("peak", xy=(np.pi / 2, 1), xytext=(2.2, 1.3), arrowprops={"arrowstyle": "->"})
ax.legend(loc="upper right")
ax.set_xticklabels(["zero", "one", "two", "three", "four", "five", "six", "seven"])
fig.set_size_inches(6, 4)
fig.tight_layout()
