"""Command-line entry point for SEETHEPLOT core."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .patcher import patch_source
from .runner import run_json_server, run_script


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="seetheplot", description="Source-aware Matplotlib layout preview engine")
    sub = parser.add_subparsers(dest="command", required=True)
    run = sub.add_parser("run", help="execute a Python plotting script")
    run.add_argument("source")
    run.add_argument("--workspace")
    run.add_argument("--mode", choices=("full", "skeleton"), default="full")
    run.add_argument("--output")
    patch = sub.add_parser("patch", help="apply supported layout operations")
    patch.add_argument("source")
    patch.add_argument("operations")
    patch.add_argument("--manifest", required=True)
    patch.add_argument("--output")
    sub.add_parser("serve", help="serve newline-delimited JSON requests")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        if args.command == "run":
            result = run_script(args.source, args.workspace, args.mode, args.output)
        elif args.command == "patch":
            manifest = json.loads(Path(args.manifest).read_text(encoding="utf-8"))
            operations = json.loads(Path(args.operations).read_text(encoding="utf-8"))
            result = patch_source(args.source, manifest, operations, args.output)
        else:
            run_json_server()
            return 0
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
