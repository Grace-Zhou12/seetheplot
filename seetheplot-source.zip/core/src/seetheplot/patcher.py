"""Minimal, format-preserving LibCST source patching."""

from __future__ import annotations

import ast
import difflib
import hashlib
import json
from pathlib import Path
from typing import Any

try:
    import libcst as cst
    from libcst.metadata import MetadataWrapper, PositionProvider
except ImportError as exc:  # pragma: no cover - exercised when dependency is absent
    cst = None  # type: ignore[assignment]
    MetadataWrapper = PositionProvider = None  # type: ignore[assignment]
    _LIBCST_ERROR = exc

from .model import EditOperation, PatchResult


def _expr(value: Any) -> Any:
    if cst is None:
        raise RuntimeError(f"LibCST is required for source patching: {_LIBCST_ERROR}")
    return cst.parse_expression(repr(value))


def _call_name(node: Any) -> str | None:
    if cst is None:
        return None
    if isinstance(node, cst.Attribute):
        return node.attr.value
    if isinstance(node, cst.Name):
        return node.value
    return None


def _arg_keyword(arg: Any) -> str | None:
    return arg.keyword.value if getattr(arg, "keyword", None) is not None else None


def _replace_positional(args: list[Any], index: int, value: Any) -> tuple[list[Any], bool]:
    positional = [i for i, arg in enumerate(args) if _arg_keyword(arg) is None and getattr(arg, "star", "") == ""]
    if index >= len(positional):
        return args, False
    actual = positional[index]
    args[actual] = args[actual].with_changes(value=_expr(value))
    return args, True


def _replace_keyword(args: list[Any], keyword: str, value: Any) -> tuple[list[Any], bool]:
    for index, arg in enumerate(args):
        if _arg_keyword(arg) == keyword:
            args[index] = arg.with_changes(value=_expr(value))
            return args, True
    insert_at = len(args)
    args.insert(insert_at, cst.Arg(keyword=cst.Name(keyword), value=_expr(value)))
    return args, True


def _replace_tuple_item(value: Any, index: int, item: Any) -> Any:
    if cst is None:
        return value
    if isinstance(value, cst.Tuple):
        elements = list(value.elements)
        if index < len(elements) and elements[index].value is not None:
            elements[index] = elements[index].with_changes(value=_expr(item))
            return value.with_changes(elements=elements)
    if isinstance(value, cst.List):
        elements = list(value.elements)
        if index < len(elements) and elements[index].value is not None:
            elements[index] = elements[index].with_changes(value=_expr(item))
            return value.with_changes(elements=elements)
    return None


def _replace_keyword_tuple(args: list[Any], keyword: str, index: int, item: Any) -> tuple[list[Any], bool]:
    for i, arg in enumerate(args):
        if _arg_keyword(arg) == keyword:
            replacement = _replace_tuple_item(arg.value, index, item)
            if replacement is None:
                return args, False
            args[i] = arg.with_changes(value=replacement)
            return args, True
    return args, False


class _PatchTransformer(cst.CSTTransformer if cst else object):
    METADATA_DEPENDENCIES = (PositionProvider,) if PositionProvider else ()

    def __init__(self, targets: dict[tuple[str, int, int], list[tuple[dict[str, Any], EditOperation]]]):
        self.targets = targets
        self.metadata = None
        self.applied: set[str] = set()
        self.unsupported: list[dict[str, Any]] = []
        self._occurrences: dict[tuple[str, int], int] = {}
        self._replacements: dict[int, Any] = {}

    def visit_Call(self, node: Any) -> bool:
        if cst is None:
            return True
        name = _call_name(node.func)
        if not name:
            return True
        position = self.get_metadata(PositionProvider, node)
        line = position.start.line
        occurrence_key = (name, line)
        occurrence = self._occurrences.get(occurrence_key, 0)
        self._occurrences[occurrence_key] = occurrence + 1
        operations = self.targets.get((name, line, occurrence), [])
        if not operations:
            return True
        args = list(node.args)
        for element, operation in operations:
            if self._apply(args, element, operation):
                self.applied.add(f"{operation.element_id}:{operation.property_path}")
            else:
                self.unsupported.append({"element_id": operation.element_id, "property_path": operation.property_path, "reason": "expression is not a supported literal or source argument was not found"})
        self._replacements[id(node)] = node.with_changes(args=args)
        return True

    def leave_Call(self, original_node: Any, updated_node: Any) -> Any:
        return self._replacements.get(id(original_node), updated_node)

    def _apply(self, args: list[Any], element: dict[str, Any], operation: EditOperation) -> bool:
        path = operation.property_path
        value = operation.value
        kind = element.get("kind")
        name = element.get("source_ref", {}).get("call_name")
        if path == "text" and kind in {"title", "axis_label", "text", "annotation"}:
            return _replace_positional(args, 0, value)[1]
        if path.startswith("font.") or path in {"color", "rotation"}:
            keyword_map = {"font.size": "fontsize", "font.family": "fontfamily", "font.weight": "fontweight", "font.style": "fontstyle", "color": "color", "rotation": "rotation"}
            return _replace_keyword(args, keyword_map[path], value)[1]
        if kind == "text" and path in {"position.x", "position.y"}:
            # Axes.text(x, y, text, ...)
            return _replace_positional(args, 1 if path.endswith(".y") else 0, value)[1]
        if kind == "title" and path == "layout.y":
            return _replace_keyword(args, "y", value)[1]
        if kind in {"title", "axis_label"} and path == "layout.loc":
            return _replace_keyword(args, "loc", value)[1]
        if kind == "axis_label" and path == "layout.labelpad":
            return _replace_keyword(args, "labelpad", value)[1]
        if kind == "annotation" and path in {"position.x", "position.y"}:
            index = 1 if path.endswith(".y") else 0
            for arg in args:
                if _arg_keyword(arg) == "xytext":
                    replacement = _replace_tuple_item(arg.value, index, value)
                    if replacement is None:
                        return False
                    args[args.index(arg)] = arg.with_changes(value=replacement)
                    return True
            return False
        if kind == "annotation" and path in {"xy.x", "xy.y", "xytext.x", "xytext.y"}:
            target = "xytext" if path.startswith("xytext") else "xy"
            index = 1 if path.endswith(".y") else 0
            for arg in args:
                if _arg_keyword(arg) == target:
                    replacement = _replace_tuple_item(arg.value, index, value)
                    if replacement is None:
                        return False
                    args[args.index(arg)] = arg.with_changes(value=replacement)
                    return True
            positional_index = 2 if target == "xytext" else 1
            return _replace_positional(args, positional_index, value)[1]
        if kind == "legend" and path == "legend.loc":
            return _replace_keyword(args, "loc", value)[1]
        if kind == "legend" and path == "legend.bbox_to_anchor":
            return _replace_keyword(args, "bbox_to_anchor", value)[1]
        if kind == "canvas" and path in {"canvas.width", "canvas.height"}:
            index = 0 if path.endswith("width") else 1
            for keyword in ("figsize",):
                for arg in args:
                    if _arg_keyword(arg) == keyword:
                        replacement = _replace_tuple_item(arg.value, index, value)
                        if replacement is None:
                            return False
                        args[args.index(arg)] = arg.with_changes(value=replacement)
                        return True
            return _replace_positional(args, index, value)[1] if name == "set_size_inches" else False
        if kind == "tick" and path == "text":
            index = int(element.get("properties", {}).get("index", 0))
            return _replace_tuple_item_in_positional(args, 0, index, value)
        return False


def _replace_tuple_item_in_positional(args: list[Any], positional_index: int, item_index: int, value: Any) -> bool:
    positional = [arg for arg in args if _arg_keyword(arg) is None]
    if positional_index >= len(positional):
        return False
    target = positional[positional_index]
    replacement = _replace_tuple_item(target.value, item_index, value)
    if replacement is None:
        return False
    args[args.index(target)] = target.with_changes(value=replacement)
    return True


def patch_source(source_path: str, manifest: dict[str, Any], operations: list[dict[str, Any] | EditOperation], output_path: str | None = None) -> dict[str, Any]:
    """Return a minimal patch; write only when ``output_path`` is provided."""
    if cst is None:
        raise RuntimeError(f"LibCST is required for source patching: {_LIBCST_ERROR}")
    source = Path(source_path).resolve()
    original = source.read_text(encoding="utf-8")
    expected_hash = manifest.get("source", {}).get("hash")
    actual_hash = hashlib.sha256(original.encode("utf-8")).hexdigest()
    if expected_hash and expected_hash != actual_hash:
        return PatchResult(original, "", warnings=["The source changed since analysis; re-analyze before applying edits."], reanalyze_required=True).to_dict()

    elements: dict[str, dict[str, Any]] = {}
    for figure in manifest.get("figures", []):
        for element in figure.get("elements", []):
            elements[element["id"]] = element
        for axes in figure.get("axes", []):
            for element in axes.get("elements", []):
                elements[element["id"]] = element

    target_map: dict[tuple[str, int, int], list[tuple[dict[str, Any], EditOperation]]] = {}
    normalized = [op if isinstance(op, EditOperation) else EditOperation.from_dict(op) for op in operations]
    unsupported: list[dict[str, Any]] = []
    for operation in normalized:
        element = elements.get(operation.element_id)
        if not element:
            unsupported.append({"element_id": operation.element_id, "property_path": operation.property_path, "reason": "unknown element"})
            continue
        ref = element.get("source_ref", {})
        if not ref.get("path") or not ref.get("start_line") or not ref.get("call_name"):
            unsupported.append({"element_id": operation.element_id, "property_path": operation.property_path, "reason": "element has no source reference"})
            continue
        key = (str(ref["call_name"]), int(ref["start_line"]), int(ref.get("occurrence", 0)))
        target_map.setdefault(key, []).append((element, operation))

    module = cst.parse_module(original)
    wrapper = MetadataWrapper(module)
    transformer = _PatchTransformer(target_map)
    changed = wrapper.visit(transformer).code
    unsupported.extend(transformer.unsupported)
    if changed == original:
        diff = ""
    else:
        diff = "".join(difflib.unified_diff(original.splitlines(True), changed.splitlines(True), fromfile=str(source), tofile=str(source)))
    if output_path:
        Path(output_path).write_text(changed, encoding="utf-8")
    return PatchResult(changed, diff, unsupported_operations=unsupported).to_dict()
