"""SEETHEPLOT's source-aware Matplotlib preview engine."""

from .model import EditOperation, Manifest, PatchResult
from .runner import run_script

__all__ = ["EditOperation", "Manifest", "PatchResult", "run_script"]
__version__ = "0.1.0"
