"""Deterministic workspace cache for preview artifacts."""

from __future__ import annotations

import hashlib
import json
import os
import platform
import shutil
import sys
from pathlib import Path
from typing import Any


def environment_fingerprint() -> dict[str, Any]:
    versions: dict[str, str] = {}
    for name in ("matplotlib", "numpy", "seaborn"):
        try:
            module = __import__(name)
            versions[name] = str(getattr(module, "__version__", "unknown"))
        except ImportError:
            versions[name] = "not-installed"
    return {"python": sys.executable, "platform": platform.platform(), "versions": versions}


def cache_key(source_path: str, options: dict[str, Any] | None = None) -> str:
    path = Path(source_path).resolve()
    payload = {
        "source": path.read_bytes().decode("utf-8"),
        "path": str(path),
        "environment": environment_fingerprint(),
        "options": options or {},
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True, default=str).encode()).hexdigest()[:24]


def cache_dir(workspace: str, key: str) -> Path:
    return Path(workspace).resolve() / ".seetheplot" / "cache" / key


def write_cache(directory: Path, manifest: dict[str, Any], diagnostics: list[dict[str, Any]]) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    (directory / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    (directory / "diagnostics.json").write_text(json.dumps(diagnostics, ensure_ascii=False, indent=2), encoding="utf-8")


def read_cache(directory: Path) -> dict[str, Any] | None:
    manifest_path = directory / "manifest.json"
    if not manifest_path.exists():
        return None
    return json.loads(manifest_path.read_text(encoding="utf-8"))


def copy_assets_to_cache(assets: dict[str, str], directory: Path) -> dict[str, str]:
    directory.mkdir(parents=True, exist_ok=True)
    copied: dict[str, str] = {}
    for name, value in assets.items():
        source = Path(value)
        target = directory / source.name
        if source.resolve() != target.resolve():
            shutil.copy2(source, target)
        copied[name] = str(target)
    return copied
