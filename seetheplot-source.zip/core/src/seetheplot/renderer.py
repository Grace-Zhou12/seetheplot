"""Convert Matplotlib figures into a serializable manifest and preview assets."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from .instrumentation import CallRecord
from .model import AxesModel, Element, FigureModel, SourceRef


def _number(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _source(record: CallRecord | None) -> SourceRef:
    if record is None:
        return SourceRef(confidence="none")
    return SourceRef(
        path=record.path,
        start_line=record.line,
        start_col=record.col,
        end_line=record.line,
        end_col=record.col,
        call_name=record.call_name,
        occurrence=record.occurrence,
        confidence="high" if record.path and record.line else "low",
    )


def _bounds(artist: Any, renderer: Any) -> dict[str, float]:
    try:
        box = artist.get_window_extent(renderer)
        return {"x": float(box.x0), "y": float(box.y0), "width": float(box.width), "height": float(box.height)}
    except Exception:
        return {}


def _font_properties(artist: Any) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, getter in {
        "font.size": "get_fontsize",
        "font.family": "get_family",
        "font.weight": "get_fontweight",
        "font.style": "get_fontstyle",
        "color": "get_color",
        "rotation": "get_rotation",
    }.items():
        try:
            value = getattr(artist, getter)()
            result[key] = list(value) if isinstance(value, tuple) else value
        except Exception:
            pass
    return result


def _record_for(records: list[CallRecord], obj: Any, kind: str | None = None) -> CallRecord | None:
    for record in reversed(records):
        if record.obj is obj and (kind is None or record.kind == kind):
            return record
    return None


def _position_metadata(artist: Any, ax: Any, properties: dict[str, Any]) -> dict[str, Any]:
    """Add enough affine metadata for the Webview to drag data-space text."""
    try:
        position = artist.get_position()
        display = artist.get_transform().transform(position)
        box = ax.get_window_extent(ax.figure.canvas.get_renderer())
        xlim = ax.get_xlim()
        ylim = ax.get_ylim()
        properties["position_display"] = [float(display[0]), float(display[1])]
        properties["axes_bounds"] = {"x": float(box.x0), "y": float(box.y0), "width": float(box.width), "height": float(box.height)}
        properties["axis_limits"] = {"x": [float(xlim[0]), float(xlim[1])], "y": [float(ylim[0]), float(ylim[1])]}
    except Exception:
        pass
    return properties


def _layout_metadata(artist: Any, ax: Any, properties: dict[str, Any]) -> dict[str, Any]:
    """Capture display and axes coordinates used by the browser overlay."""
    _position_metadata(artist, ax, properties)
    try:
        position = artist.get_position()
        properties["layout_position"] = [float(position[0]), float(position[1])]
    except Exception:
        pass
    return properties


def _element(element_id: str, kind: str, artist: Any, renderer: Any, record: CallRecord | None, properties: dict[str, Any], editable: list[str]) -> Element:
    transform = "display"
    try:
        transform = str(artist.get_transform())
    except Exception:
        pass
    return Element(
        id=element_id,
        kind=kind,
        source_ref=_source(record),
        bounds=_bounds(artist, renderer),
        transform=transform,
        properties=properties,
        editable_properties=editable,
        confidence=_source(record).confidence,
    )


def build_manifest(figures: list[Any], records: list[CallRecord], source: dict[str, Any], assets: dict[str, str], diagnostics: list[dict[str, Any]]) -> dict[str, Any]:
    """Build the v1 manifest after the canvas has been drawn."""
    result: list[FigureModel] = []
    for fig_index, fig in enumerate(figures):
        canvas = fig.canvas
        renderer = canvas.get_renderer()
        width, height = fig.get_size_inches()
        figure = FigureModel(
            f"figure-{fig_index}",
            float(width),
            float(height),
            float(fig.dpi),
            width_px=float(width * fig.dpi),
            height_px=float(height * fig.dpi),
        )
        record = _record_for(records, fig, "canvas")
        figure.elements.append(_element(
            f"figure-{fig_index}-canvas", "canvas", fig, renderer, record,
            {
                "width": float(width),
                "height": float(height),
                "dpi": float(fig.dpi),
                "width_px": float(width * fig.dpi),
                "height_px": float(height * fig.dpi),
            },
            ["canvas.width", "canvas.height"],
        ))

        for ax_index, ax in enumerate(fig.axes):
            ax_id = f"figure-{fig_index}-axes-{ax_index}"
            ax_box = ax.get_window_extent(renderer)
            axes = AxesModel(ax_id, {"x": float(ax_box.x0), "y": float(ax_box.y0), "width": float(ax_box.width), "height": float(ax_box.height)})
            title = ax.get_title(text=True) if False else ax.title
            if title.get_text():
                axes.elements.append(_element(
                    f"{ax_id}-title", "title", title, renderer, _record_for(records, title),
                    _layout_metadata(title, ax, {"text": title.get_text(), **_font_properties(title), "position": list(title.get_position()), "layout": "title"}),
                    ["text", "font.size", "font.family", "font.weight", "font.style", "color", "rotation", "layout.y", "layout.loc"],
                ))
            for label_name, label in (("xlabel", ax.xaxis.label), ("ylabel", ax.yaxis.label)):
                if label.get_text():
                    axes.elements.append(_element(
                        f"{ax_id}-{label_name}", "axis_label", label, renderer, _record_for(records, label),
                        _layout_metadata(label, ax, {"text": label.get_text(), **_font_properties(label), "position": list(label.get_position()), "layout": label_name, "labelpad": float(getattr(ax.xaxis if label_name == "xlabel" else ax.yaxis, "labelpad", 4.0))}),
                        ["text", "font.size", "font.family", "font.weight", "font.style", "color", "rotation", "layout.loc", "layout.labelpad"],
                    ))
            for text_index, text_artist in enumerate(ax.texts):
                if text_artist is title or text_artist in (ax.xaxis.label, ax.yaxis.label):
                    continue
                kind = "annotation" if text_artist.__class__.__name__ == "Annotation" else "text"
                props = _position_metadata(text_artist, ax, {"text": text_artist.get_text(), **_font_properties(text_artist), "position": list(text_artist.get_position())})
                if kind == "annotation":
                    try:
                        props["xy"] = list(text_artist.xy)
                        props["xytext"] = list(text_artist.xyann)
                    except Exception:
                        pass
                axes.elements.append(_element(
                    f"{ax_id}-{kind}-{text_index}", kind, text_artist, renderer,
                    _record_for(records, text_artist), props,
                    ["text", "position.x", "position.y", "font.size", "font.family", "font.weight", "font.style", "color", "rotation"] + (["xy.x", "xy.y", "xytext.x", "xytext.y"] if kind == "annotation" else []),
                ))
            for legend_index, legend in enumerate(ax.get_legend() and [ax.get_legend()] or []):
                props = {"loc": str(getattr(legend, "_loc", "best")), "fontsize": _number(legend.get_texts()[0].get_fontsize()) if legend.get_texts() else None}
                try:
                    anchor = legend.get_bbox_to_anchor().transformed(ax.transAxes.inverted())
                    props["bbox_to_anchor"] = [float(anchor.x0), float(anchor.y0), float(anchor.width), float(anchor.height)]
                    props["axes_bounds"] = {"x": float(ax_box.x0), "y": float(ax_box.y0), "width": float(ax_box.width), "height": float(ax_box.height)}
                except Exception:
                    pass
                axes.elements.append(_element(
                    f"{ax_id}-legend-{legend_index}", "legend", legend, renderer,
                    _record_for(records, legend), props,
                    ["legend.loc", "legend.bbox_to_anchor", "font.size"],
                ))
            tick_records = [r for r in records if r.kind == "tick" and r.call_name in {"set_xticklabels", "set_yticklabels"}]
            for direction, axis in (("x", ax.xaxis), ("y", ax.yaxis)):
                for tick_index, label in enumerate(axis.get_ticklabels()):
                    if not label.get_text():
                        continue
                    rec = tick_records[-1] if tick_records else None
                    axes.elements.append(_element(
                        f"{ax_id}-{direction}-tick-{tick_index}", "tick", label, renderer, rec,
                        {"axis": direction, "index": tick_index, "text": label.get_text(), **_font_properties(label)},
                        ["text", "rotation", "font.size", "font.family", "font.weight", "font.style", "color"],
                    ))
            figure.axes.append(axes)
        result.append(figure)
    return {"schema_version": 1, "source": source, "figures": [__import__("dataclasses").asdict(item) for item in result], "assets": assets, "diagnostics": diagnostics}


def make_skeleton(figures: list[Any]) -> None:
    """Hide data artists in-place while retaining layout artists."""
    from matplotlib.collections import Collection
    from matplotlib.image import AxesImage, FigureImage
    from matplotlib.lines import Line2D
    from matplotlib.patches import Patch

    for fig in figures:
        for artist in fig.get_children():
            if isinstance(artist, FigureImage):
                artist.set_visible(False)
        for ax in fig.axes:
            for artist in list(ax.lines) + list(ax.collections) + list(ax.images) + list(ax.patches):
                if artist is ax.patch:
                    continue
                if isinstance(artist, (Line2D, Collection, AxesImage, Patch)):
                    artist.set_visible(False)


def save_previews(figures: list[Any], output_dir: str) -> dict[str, str]:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    full = output / "full.svg"
    skeleton = output / "skeleton.svg"
    if not figures:
        raise RuntimeError("The script did not create any Matplotlib figures")
    # Keep the native figure canvas instead of cropping it. The browser overlay
    # uses Matplotlib display coordinates, so a cropped SVG would shift every
    # editable element away from its visible location.
    figures[0].savefig(full, format="svg")
    old: list[tuple[Any, bool]] = []
    for fig in figures:
        for artist in fig.findobj():
            try:
                old.append((artist, artist.get_visible()))
            except Exception:
                pass
    make_skeleton(figures)
    figures[0].savefig(skeleton, format="svg")
    for artist, visible in old:
        try:
            artist.set_visible(visible)
        except Exception:
            pass
    return {"full_render": str(full), "skeleton_render": str(skeleton)}
