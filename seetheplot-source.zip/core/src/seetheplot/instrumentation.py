"""Lightweight runtime tracing for common Matplotlib layout APIs."""

from __future__ import annotations

import inspect
import os
from dataclasses import dataclass
from functools import wraps
from typing import Any, Callable


@dataclass
class CallRecord:
    obj: Any
    kind: str
    call_name: str
    path: str | None
    line: int | None
    col: int | None
    occurrence: int = 0


class Instrumentation:
    """Patch user-facing methods and remember the objects they create."""

    def __init__(self, source_path: str, working_dir: str):
        self.source_path = os.path.realpath(source_path)
        self.working_dir = os.path.realpath(working_dir)
        self.records: list[CallRecord] = []
        self._originals: list[tuple[Any, str, Any]] = []
        self._occurrences: dict[tuple[str, int], int] = {}

    def _callsite(self) -> tuple[str | None, int | None, int | None]:
        for frame in inspect.stack()[2:]:
            path = os.path.realpath(frame.filename)
            if path == self.source_path or (
                path.startswith(self.working_dir + os.sep)
                and "seetheplot" not in path
            ):
                return path, frame.lineno, 0
        return None, None, None

    def _record(self, obj: Any, kind: str, call_name: str) -> None:
        path, line, col = self._callsite()
        occurrence = 0
        if line is not None:
            key = (call_name, line)
            occurrence = self._occurrences.get(key, 0)
            self._occurrences[key] = occurrence + 1
        self.records.append(CallRecord(obj, kind, call_name, path, line, col, occurrence))

    def _patch_method(self, owner: Any, name: str, kind: str) -> None:
        original = getattr(owner, name)

        @wraps(original)
        def wrapped(instance: Any, *args: Any, **kwargs: Any) -> Any:
            result = original(instance, *args, **kwargs)
            value = result
            if name in {"set_xticklabels", "set_yticklabels"} and isinstance(result, (list, tuple)):
                for item in result:
                    self._record(item, "tick", name)
                return result
            if name in {"set_xticks", "set_yticks", "tick_params"}:
                self._record(instance, "tick_config", name)
            elif name == "set_size_inches":
                self._record(instance, "canvas", name)
            else:
                self._record(value, kind, name)
            return result

        self._originals.append((owner, name, original))
        setattr(owner, name, wrapped)

    def install(self) -> None:
        import matplotlib.axes
        import matplotlib.figure
        import matplotlib.pyplot as plt

        methods = [
            (matplotlib.axes.Axes, "set_title", "title"),
            (matplotlib.axes.Axes, "set_xlabel", "axis_label"),
            (matplotlib.axes.Axes, "set_ylabel", "axis_label"),
            (matplotlib.axes.Axes, "text", "text"),
            (matplotlib.axes.Axes, "annotate", "annotation"),
            (matplotlib.axes.Axes, "legend", "legend"),
            (matplotlib.axes.Axes, "set_xticklabels", "tick"),
            (matplotlib.axes.Axes, "set_yticklabels", "tick"),
            (matplotlib.axes.Axes, "set_xticks", "tick_config"),
            (matplotlib.axes.Axes, "set_yticks", "tick_config"),
            (matplotlib.axes.Axes, "tick_params", "tick_config"),
            (matplotlib.figure.Figure, "text", "text"),
            (matplotlib.figure.Figure, "suptitle", "title"),
            (matplotlib.figure.Figure, "set_size_inches", "canvas"),
        ]
        for owner, name, kind in methods:
            self._patch_method(owner, name, kind)

        pyplot_functions = {
            "title": "title",
            "xlabel": "axis_label",
            "ylabel": "axis_label",
            "text": "text",
            "annotate": "annotation",
            "legend": "legend",
        }
        for name, kind in pyplot_functions.items():
            original = getattr(plt, name)

            @wraps(original)
            def wrapped(*args: Any, _original: Callable[..., Any] = original, _name: str = name, _kind: str = kind, **kwargs: Any) -> Any:
                result = _original(*args, **kwargs)
                self._record(result, _kind, _name)
                return result

            self._originals.append((plt, name, original))
            setattr(plt, name, wrapped)

        for name in ("figure", "subplots", "subplot_mosaic"):
            original = getattr(plt, name)

            @wraps(original)
            def create_figure(*args: Any, _original: Callable[..., Any] = original, _name: str = name, **kwargs: Any) -> Any:
                result = _original(*args, **kwargs)
                figure = result[0] if _name in {"subplots", "subplot_mosaic"} else result
                self._record(figure, "canvas", _name)
                return result

            self._originals.append((plt, name, original))
            setattr(plt, name, create_figure)

    def uninstall(self) -> None:
        for owner, name, original in reversed(self._originals):
            setattr(owner, name, original)
        self._originals.clear()
