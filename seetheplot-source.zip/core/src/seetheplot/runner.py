"""Run a plotting script in a non-interactive child process and emit artifacts."""

from __future__ import annotations

import hashlib
import json
import os
import runpy
import sys
import traceback
from pathlib import Path
from typing import Any

from .cache import cache_dir, cache_key, copy_assets_to_cache, environment_fingerprint, read_cache, write_cache
from .instrumentation import Instrumentation
from .renderer import build_manifest, save_previews


def _source_info(path: Path) -> dict[str, Any]:
    content = path.read_bytes()
    return {"path": str(path), "hash": hashlib.sha256(content).hexdigest(), "python": sys.executable}


def run_script(
    source_path: str,
    workspace: str | None = None,
    mode: str = "full",
    output_dir: str | None = None,
) -> dict[str, Any]:
    """Execute ``source_path`` and return a v1 manifest dictionary.

    The function is intentionally synchronous; the VS Code extension owns the
    subprocess and can terminate it to implement cancellation and timeouts.
    """
    source = Path(source_path).resolve()
    if not source.exists() or source.suffix != ".py":
        raise FileNotFoundError(f"Python source file not found: {source}")
    workspace_path = Path(workspace or source.parent).resolve()
    # Set writable cache locations before importing Matplotlib indirectly via
    # environment_fingerprint(). This avoids contaminating the user's global
    # Matplotlib/font caches during a preview run.
    os.environ.setdefault("MPLCONFIGDIR", str(workspace_path / ".seetheplot" / "mplconfig"))
    os.environ.setdefault("XDG_CACHE_HOME", str(workspace_path / ".seetheplot" / "xdg-cache"))
    key = cache_key(str(source), {"mode": mode})
    destination = Path(output_dir).resolve() if output_dir else cache_dir(str(workspace_path), key)
    destination.mkdir(parents=True, exist_ok=True)

    os.environ.setdefault("MPLBACKEND", "Agg")
    os.environ.setdefault("MPLCONFIGDIR", str(destination / "mplconfig"))
    os.environ.setdefault("XDG_CACHE_HOME", str(destination / "xdg-cache"))

    try:
        import matplotlib
        matplotlib.use("Agg", force=True)
        import matplotlib.pyplot as plt
    except Exception as exc:  # pragma: no cover - environment-specific
        raise RuntimeError(f"Matplotlib could not be initialized: {exc}") from exc

    plt.close("all")
    tracer = Instrumentation(str(source), str(workspace_path))
    tracer.install()
    diagnostics: list[dict[str, Any]] = []
    try:
        runpy.run_path(str(source), run_name="__main__")
        figures = [manager.canvas.figure for manager in matplotlib._pylab_helpers.Gcf.get_all_fig_managers()]
        if not figures:
            raise RuntimeError("The script did not create any Matplotlib figures")
        for fig in figures:
            fig.canvas.draw()
        assets = save_previews(figures, str(destination))
        manifest = build_manifest(figures, tracer.records, _source_info(source), assets, diagnostics)
        manifest["cache_key"] = key
        manifest["source"]["environment"] = environment_fingerprint()
        manifest["assets"] = copy_assets_to_cache(assets, destination)
        write_cache(destination, manifest, diagnostics)
        return manifest
    except Exception as exc:
        diagnostics.append({"level": "error", "message": str(exc), "traceback": traceback.format_exc()})
        raise
    finally:
        tracer.uninstall()


def load_cached(source_path: str, workspace: str | None = None, mode: str = "full") -> dict[str, Any] | None:
    source = Path(source_path).resolve()
    directory = cache_dir(str(Path(workspace or source.parent).resolve()), cache_key(str(source), {"mode": mode}))
    return read_cache(directory)


def serve_json_request(request: dict[str, Any]) -> dict[str, Any]:
    command = request.get("command", "run")
    if command == "run":
        return run_script(
            request["source_path"],
            workspace=request.get("workspace"),
            mode=request.get("mode", "full"),
            output_dir=request.get("output_dir"),
        )
    if command == "cache":
        result = load_cached(request["source_path"], request.get("workspace"), request.get("mode", "full"))
        return result or {"cache": None}
    if command == "patch":
        from .patcher import patch_source

        return patch_source(request["source_path"], request["manifest"], request.get("operations", []))
    raise ValueError(f"Unknown command: {command}")


def run_json_server() -> None:
    for line in sys.stdin:
        if not line.strip():
            continue
        try:
            result = serve_json_request(json.loads(line))
            print(json.dumps({"ok": True, "result": result}, ensure_ascii=False), flush=True)
        except Exception as exc:
            print(json.dumps({"ok": False, "error": str(exc), "traceback": traceback.format_exc()}, ensure_ascii=False), flush=True)
