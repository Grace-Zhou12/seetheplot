"""Serializable models shared by the runner, patcher, and VS Code client."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class SourceRef:
    path: str | None = None
    start_line: int | None = None
    start_col: int | None = None
    end_line: int | None = None
    end_col: int | None = None
    call_name: str | None = None
    occurrence: int = 0
    confidence: str = "unknown"


@dataclass
class Element:
    id: str
    kind: str
    source_ref: SourceRef = field(default_factory=SourceRef)
    bounds: dict[str, float] = field(default_factory=dict)
    transform: str = "display"
    properties: dict[str, Any] = field(default_factory=dict)
    editable_properties: list[str] = field(default_factory=list)
    confidence: str = "unknown"


@dataclass
class AxesModel:
    id: str
    bounds: dict[str, float] = field(default_factory=dict)
    elements: list[Element] = field(default_factory=list)


@dataclass
class FigureModel:
    id: str
    width: float
    height: float
    dpi: float
    width_px: float = 0.0
    height_px: float = 0.0
    axes: list[AxesModel] = field(default_factory=list)
    elements: list[Element] = field(default_factory=list)


@dataclass
class Manifest:
    schema_version: int
    source: dict[str, Any]
    figures: list[FigureModel]
    assets: dict[str, str]
    diagnostics: list[dict[str, Any]] = field(default_factory=list)
    cache_key: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class EditOperation:
    element_id: str
    property_path: str
    value: Any

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "EditOperation":
        return cls(
            element_id=str(value["element_id"]),
            property_path=str(value["property_path"]),
            value=value.get("value"),
        )


@dataclass
class PatchResult:
    changed_source: str
    diff: str
    warnings: list[str] = field(default_factory=list)
    unsupported_operations: list[dict[str, Any]] = field(default_factory=list)
    reanalyze_required: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
