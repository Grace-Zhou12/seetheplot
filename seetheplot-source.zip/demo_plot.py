"""A small SEETHEPLOT smoke-test figure."""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np


fig, ax = plt.subplots(figsize=(8, 5), dpi=120)
x = np.linspace(0, 2 * np.pi, 100)
y = np.sin(x)

ax.plot(x, y, color="#2878b5", linewidth=2.5, label="sin(x)")
ax.scatter([np.pi / 2], [1], color="#d95f02", zorder=3, label="peak")
ax.set_title("SEETHEPLOT layout preview", fontsize=18, pad=14, rotation = 0)
ax.set_xlabel("Angle (radians)", fontsize=12)
ax.set_ylabel("Amplitude", fontsize=12)
ax.text(4.104575897419504, 0.6526333394885218, "Drag this note\nin the preview", fontsize=11, color="#444444")
ax.annotate(
    "maximum",
    xy=(np.pi / 2, 1),
    xytext=(3.2223520737512885, 0.4856153196197109),
    arrowprops={"arrowstyle": "->", "color": "#d95f02", "linewidth": 1.5},
    fontsize=11,
)
ax.legend(loc="lower left", frameon=True)
ax.grid(alpha=0.25)
fig.tight_layout()

# Keep a directly viewable PNG beside this smoke-test script.
fig.savefig(Path(__file__).with_name("demo_plot.png"), dpi=160, bbox_inches="tight")
